﻿Console.Write(command);

CreateFile("Имя файла", "txt");

#region DEBUG
#warning DEBUG
string command = Console.ReadLine();
if (command.Contains("find"))
{
}
if (command.Contains("create"))
{
	//string fileName = command.Substring(command.IndexOf("-name") + "-name".Length);
	string extension = command.Substring(command.IndexOf("-ext") + "-ext".Length);
	Console.WriteLine(extension);
	Console.ReadLine();
}
#endregion DEBUG


#region Commands

static void CreateFile(string fileName, string extension)
{
	// string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), $"{fileName}.{extension}");
	// File.Create(path);
	Console.WriteLine("Файл создан!");
}